ALTER TABLE "session" DROP COLUMN created;
